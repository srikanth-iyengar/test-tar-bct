const express = require('express');
const bodyParser = require('body-parser');
const truffleContract = require('truffle-contract');
const Web3 = require('web3');

const app = express();
const port = 3000;

app.use(bodyParser.json());

// Load the smart contract
const TwoFactorAuthJSON = require('./build/contracts/TwoFactorAuth.json'); // Replace with the correct path
const TwoFactorAuth = truffleContract(TwoFactorAuthJSON);
const web3Provider = new Web3.providers.HttpProvider('http://localhost:8545'); // Replace with your Ethereum node URL
TwoFactorAuth.setProvider(web3Provider);

// Middleware for authentication
function authenticateUser(req, res, next) {
  const { address, oneTimePassword } = req.body;

  // You should implement your own user management here, for simplicity we'll just use a user object
  const user = {
    address: '0xYourUserAddress', // Replace with the actual user address
    secret: 'YourSecretKey', // Replace with the actual secret key
  };

  // Verify the one-time password
  const isValid = verifyOneTimePassword(user.secret, oneTimePassword);

  if (address === user.address && isValid) {
    next(); // User is authenticated
  } else {
    res.status(401).json({ message: 'Authentication failed' });
  }
}

function verifyOneTimePassword(secret, oneTimePassword) {
  // You should use a proper 2FA library to generate and verify one-time passwords
  // For simplicity, we'll use a placeholder function here
  return oneTimePassword === generateOneTimePassword(secret);
}

function generateOneTimePassword(secret) {
  // You should use a proper 2FA library to generate one-time passwords
  // For simplicity, we'll use a placeholder function here
  return '123456'; // Replace with the actual one-time password generation logic
}

app.post('/authenticate', authenticateUser, async (req, res) => {
  res.json({ message: 'Authentication successful' });
});

app.listen(port, () => {
  console.log(`2FA server is running on port ${port}`);
});

